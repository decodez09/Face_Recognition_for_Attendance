import ast
import Sample_Generator
import Model_Trainer
import Face_Recognition
import os
import shutil

try:
    f = open("Face_Recognition_for_Attendance/counter.txt")
    count = int(f.read())
    f.close()
except:
    count = 0
    
path = 'C:/Users/HARSH JAISWAL/AppData/Local/Programs/Python/Python310/Face_Recognition_for_Attendance/samples/'# path of this folder

while True:
    
    print("1. Add Data")
    print("2. Give Attendance")
    print("3. Print Total Attendance")
    print("4. Delete Data")
    print("5. Exit The Program")
    
    
    
    n = int(input("Enter your choice: "))



    match n:
        case 1: # creating datasets
            s = input("Enter Name: ")
            id = int(input("Enter ID: "))
            try:
                f = open("Face_Recognition_for_Attendance/data.txt")
                dic=ast.literal_eval(f.read())
                f.close()
            except:
                dic={}
            if id not in dic.keys() or (s in dic.values() and id in dic.keys()):
                
                dic.update({id:s})
                f = open("Face_Recognition_for_Attendance/data.txt","w")
                f.write(str(dic))
                f.close()
                Sample_Generator.takeSamples(id,100) #nnumber of samples Generated default = 50 for better accuracy increase it
                Model_Trainer.train()
            else:
                print("ID cannot be same")
            
        case 2: # marking attendance
            f = open("Face_Recognition_for_Attendance/data.txt")
            dic=ast.literal_eval(f.read())
            l = len(dic)
            f.close()
            global score
            id, score = Face_Recognition.recognize()
            if id in dic.keys():
                try:
                    f = open("Face_Recognition_for_Attendance/data2.txt")
                    dict1=ast.literal_eval(f.read())
                    f.close()
                except:
                    dict1 = dict(dic)
                    for i in range(1,l+1):
                        dict1[i] = [0,0,0,0,0,0,0,0,0,0] # default is absent
                # for i in range(1,l+1):
                #     dict1[i][count] = 0
                dict1[id][count] = 1
                #print(dict1)
                f = open("Face_Recognition_for_Attendance/data2.txt","w")
                f.write(str(dict1))
                f.close()
                print("Thankyou, Your Attendance is Marked")
                    
        case 3: # print the total attendance
            try:
                f1 = open("Face_Recognition_for_Attendance/data.txt")
                data = ast.literal_eval(f1.read())
                f1.close()
                l = len(data)
                #print(data)
                f1 = open("Face_Recognition_for_Attendance/data2.txt")
                data1 = ast.literal_eval(f1.read())
                f1.close()
                #print(data1)
                sum = 0
                print("ID    Name    Day 1    Day 2    Day 3    Day 4    Day 5    Day 6    Day 7    Day 8    Day 9    Day 10    Total")
                for i in range(1,l+1):
                    print(str(i)+4*" "+str(data[i]), end="    ")
                    for j in range(0,10):
                        if data1[i][j] == 0:
                            print("Absent", end = "    ")  # default is absent
                        else:
                            print("Present", end = "    ")
                        sum += data1[i][j]
                    print(str(sum), end=" ")
                    sum = 0
                    print()
                break
            except:
                print("No Data available")
                break
        case 4:# deleting all the data
            f = open("Face_Recognition_for_Attendance/data.txt",'w')
            f.truncate(0)
            f.close()
            shutil.rmtree(path)
            os.mkdir(path)
            f = open("Face_Recognition_for_Attendance/counter.txt",'w')
            f.truncate(0)
            f.close()
            f = open("Face_Recognition_for_Attendance/data2.txt",'w')
            f.truncate(0)
            f.close()
            print("Data Deleted")
            break
        case 5: #exiting the program
            f = open("Face_Recognition_for_Attendance/counter.txt",'w')
            count+=1
            f.write(str(count))
            f.close()
            break
        case _:
            print("Wrong Choice")
        

print("Program by Harsh Jaiswal...")
