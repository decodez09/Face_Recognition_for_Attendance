﻿Hello, My name is Harsh Jaiswal. I am persuing BCA (2nd year) from University of Lucknow.
I was Selected in SAMSUNG INNOVATION CAMPUS PROGRAM as Artificial Intelligence course.
I was given a project - FACE RECOGNITION ATTENDANCE SYSTEM with my team members- Kunal Gupta, Adarsh Mishra and Abhishek Dwivedi.
I completed my project with my best efforts.
I am sorry if there are any errors.
 
Thank you!!
 
 
To run this project you have to run "main.py".
 
NOTE: Do not edit other text files. If so run "main.py" and delete the data.
